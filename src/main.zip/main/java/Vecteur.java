public class Vecteur{

	// Point d'origine du vecteur 

	private Point p;

	public Vecteur(Point p){
		this.p=p;
	}

	//Récupère le point d'origine du vecteur

	public Point getPoint(){
		return this.p;
	}
}