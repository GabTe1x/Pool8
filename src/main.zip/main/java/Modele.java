
public class Modele {
	private Bille b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15;
	private Joueur j1, j2;
	private Vecteur vecteur;
	private Point point;
	
	

	public Modele(Bille b1, Bille b2,Bille b3, Bille b4,Bille b5, Bille b6,Bille b7, Bille b8,Bille b9, Bille b10,Bille b11, Bille b12,Bille b13, Bille b14,Bille b15) {
		this.b1=b1;
		this.b2=b2;
		this.b3=b3;
		this.b4=b4;
		this.b5=b5;
		this.b6=b6;
		this.b7=b7;
		this.b8=b8;
		this.b9=b9;
		this.b10=b10;
		this.b11=b12;
		this.b12=b12;
		this.b13=b13;
		this.b14=b14;
		this.b15=b15;
	}

	public Bille getB1() {
		return b1;
	}

	public void setB1(Bille b1) {
		this.b1 = b1;
	}

	public Bille getB2() {
		return b2;
	}

	public void setB2(Bille b2) {
		this.b2 = b2;
	}

	public Bille getB3() {
		return b3;
	}

	public void setB3(Bille b3) {
		this.b3 = b3;
	}

	public Bille getB4() {
		return b4;
	}

	public void setB4(Bille b4) {
		this.b4 = b4;
	}

	public Bille getB5() {
		return b5;
	}

	public void setB5(Bille b5) {
		this.b5 = b5;
	}

	public Bille getB6() {
		return b6;
	}

	public void setB6(Bille b6) {
		this.b6 = b6;
	}

	public Bille getB7() {
		return b7;
	}

	public void setB7(Bille b7) {
		this.b7 = b7;
	}

	public Bille getB8() {
		return b8;
	}

	public void setB8(Bille b8) {
		this.b8 = b8;
	}

	public Bille getB9() {
		return b9;
	}

	public void setB9(Bille b9) {
		this.b9 = b9;
	}

	public Bille getB10() {
		return b10;
	}

	public void setB10(Bille b10) {
		this.b10 = b10;
	}

	public Bille getB11() {
		return b11;
	}

	public void setB11(Bille b11) {
		this.b11 = b11;
	}

	public Bille getB12() {
		return b12;
	}

	public void setB12(Bille b12) {
		this.b12 = b12;
	}

	public Bille getB13() {
		return b13;
	}

	public void setB13(Bille b13) {
		this.b13 = b13;
	}

	public Bille getB14() {
		return b14;
	}

	public void setB14(Bille b14) {
		this.b14 = b14;
	}

	public Bille getB15() {
		return b15;
	}

	public void setB15(Bille b15) {
		this.b15 = b15;
	}
	public Joueur getJ1() {
		return j1;
	}

	public void setJ1(Joueur j1) {
		this.j1 = j1;
	}

	public Joueur getJ2() {
		return j2;
	}

	public void setJ2(Joueur j2) {
		this.j2 = j2;
	}
	
	public Vecteur getVecteur() {
		return vecteur;
	}

	public void setVecteur(Vecteur vecteur) {
		this.vecteur = vecteur;
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}
}
