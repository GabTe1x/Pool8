import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;

public class Plateau extends StackPane{
	
	
    final int longueur = 900;
	final int largeur = 600;//cm partie jouable
	Trou t1,t2,t3,t4,t5,t6;
	Bande b1,b2,b3,b4,b5,b6;
	
	public Plateau()throws Exception {
		super();
		this.setPrefSize(longueur+200,largeur+50 );
		//on récupère l'image de background et on ajuste la taille
        InputStream is = Files.newInputStream(Paths.get("src/main/ressources/sol.jpg"));
        Image bg=new Image(is);
        is.close();
        ImageView bgView=new ImageView(bg);
        bgView.setFitWidth(longueur+200);
        bgView.setFitHeight(largeur+50);
		//on récupère l'image de background et on ajuste la taille
        InputStream s = Files.newInputStream(Paths.get("src/main/ressources/TableBillard.png"));
        Image pl=new Image(s);
        s.close();
        ImageView plateau=new ImageView(pl);
        plateau.setFitWidth(longueur);
        plateau.setFitHeight(largeur);
		//Initialisation des trous
		this.getChildren().addAll(bgView,plateau);
        
		t1 = new Trou(0,0);
		t2 = new Trou(327,0);
		t3 = new Trou(0,300);
		t4 = new Trou(327,300);
		t5 = new Trou(0,600);
		t6 = new Trou(327,600);
		
		// Initialisation des Bandes
		
		b1 = new Bande(30,0,267,10);
		b2 = new Bande(30,590,267,10);
		b3 = new Bande(0,30,255,10);
		b4 = new Bande(317,30,255,10);
		b5 = new Bande(0,315,255,10);
		b6 = new Bande(317,315,255,10);
		
		
		
		
	}
	
	
	public class Trou {
		
		int x;
		int y;
		final int diam = 30;
		
		public Trou (int x, int y) {
			this.x = x ;
			this.y = y ;	
		}
	}
	
	
	public class Bande {
		
		int x;
		int y;
		int lon;
		int lar;
		
		public Bande (int x, int y, int lon, int lar) {
			this.x = x ;
			this.y = y ;
			this.lon = lon ;
			this.lar = lar ;
			
		}
	}
	
}
	